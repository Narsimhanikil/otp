package com.example.otp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    EditText phonenum,codeenter;
    Button mextBtn;
    ProgressBar progressBar;
    TextView textView;
    CountryCodePicker countryCodePicker;
    PhoneAuthProvider.ForceResendingToken Token;
    String verid;
    Boolean verifyprog=false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firebaseAuth=FirebaseAuth.getInstance();
        phonenum=findViewById(R.id.phone);
        codeenter=findViewById(R.id.codeEnter);
        progressBar=findViewById(R.id.progressBar);
        mextBtn=findViewById(R.id.nextBtn);
        textView=findViewById(R.id.state);
        countryCodePicker=findViewById(R.id.ccp);
        mextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!verifyprog) {
                    if (!phonenum.getText().toString().isEmpty() && phonenum.getText().toString().length() == 10) {
                        String phonenumber = "+" + countryCodePicker.getSelectedCountryCode() + phonenum.getText().toString();
                        Log.d("TAG", "PHONENUM" + phonenumber);
                        progressBar.setVisibility(View.VISIBLE);
                        textView.setVisibility(View.VISIBLE);
                        requestOtp(phonenumber);

                    } else {
                        Toast.makeText(MainActivity.this, "not valid", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    String userotp=codeenter.getText().toString();
                    if(!userotp.isEmpty()&&userotp.length()==6) {
                        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verid, userotp);
                        verifyAuth(credential);
                    }
                }
            }
        });

    }
    private  void  verifyAuth(PhoneAuthCredential credential){
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
            if(task.isSuccessful()){
                Toast.makeText(MainActivity.this, "sucess", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(intent);
            }else {
                Toast.makeText(MainActivity.this, "failed", Toast.LENGTH_SHORT).show();
            }
            }
        });
    }
    private void requestOtp( String phonenumber){
        PhoneAuthProvider.getInstance().verifyPhoneNumber(phonenumber, 60L, TimeUnit.SECONDS, this, new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                progressBar.setVisibility(View.GONE);
                textView.setVisibility(View.GONE);
                codeenter.setVisibility(View.VISIBLE);
                mextBtn.setText("Verify");
                verid=s;
                Token=forceResendingToken;
               verifyprog=true;
                super.onCodeSent(s, forceResendingToken);
            }

            @Override
            public void onCodeAutoRetrievalTimeOut(String s) {
                super.onCodeAutoRetrievalTimeOut(s);
            }

            @Override
            public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                Toast.makeText(MainActivity.this, "failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}